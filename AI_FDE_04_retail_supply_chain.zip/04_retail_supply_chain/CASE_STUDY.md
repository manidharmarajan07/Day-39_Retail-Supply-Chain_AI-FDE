# Case Study — Retail Supply Chain & Demand Replenishment

**Domain:** Retail / Supply Chain  
**Mission:** Modernize a replenishment platform that receives inventory events, generates demand-risk signals, and supports planner interventions.

## Brownfield situation
The service escaped pilot discipline. It runs, but identity boundaries collapsed into shared administration; secrets and environment data were copied into tracked files; infrastructure is recreated manually; releases bypass meaningful gates; telemetry is insufficient for cross-service diagnosis; the load test is non-representative; and recovery/go-live ownership is unclear. A pilot AI dependency was added without matching production controls.

**Important:** these defects are intentional. The starting repo must remain problematic until participants execute the transformation prompts.

## Business-critical surface
inventory events, replenishment recommendations, planner actions, network administration, demand-risk scoring.

## AI dependency
demand-risk scoring service. Treat it as a production dependency with identity, network, timeout, telemetry, SLO and failure-mode requirements.

## Growth / change pressure
Peak workload may reach **20× pilot volume**. The platform must support controlled change without granting persistent broad privilege or turning AI failure into an uncontrolled business failure.

## Participant mission
Transform the existing repo rather than replacing it wholesale. Every material change must trace `Finding → Decision → Change → Test → Evidence`.

## Constraints
- Synthetic data only.
- Cloud-agnostic target unless a provider is explicitly selected.
- Preserve business behavior where practical; justify breaking changes.
- No greenfield replacement presented as brownfield remediation.
- Do not claim a capability without executable or inspectable evidence.

## Expanded evidence pack
The brownfield repository now includes a broader synthetic evidence surface under `repo/data/`, plus `environment_matrix.csv`, expanded legacy identity/access data, known-risk records, incident history and business/operational context. These artifacts intentionally contain normal, edge, degraded and contradictory patterns so participants must correlate evidence across code, data, IAM, infrastructure, delivery and operations.

Participants are expected to use these artifacts during D1–D8 and again when validating T1–T8, the integration review, both challenges and the final PRD.
