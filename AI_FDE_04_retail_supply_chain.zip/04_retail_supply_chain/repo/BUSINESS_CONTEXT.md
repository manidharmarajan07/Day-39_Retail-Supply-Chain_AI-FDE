# Business & Operational Context — Retail Supply Chain & Demand Replenishment

## Why this system exists
This platform supports a business-critical operational workflow in **Retail / Supply Chain**. The brownfield version grew from a pilot into a production-like service without a corresponding increase in platform engineering discipline.

## Stakeholder tensions
- Business operations want faster change and fewer manual steps.
- Security wants least privilege, auditable access and controlled secrets.
- Platform engineering wants reproducible environments and safer releases.
- Operations wants measurable SLOs, actionable telemetry and recovery evidence.
- Product teams want the AI capability retained, but the AI dependency is not always reliable.
- Compliance/audit stakeholders require evidence rather than architecture claims.

## Traffic and operating assumptions
- Normal load varies materially by hour, region, batch/window and business event.
- Peak conditions can reach **20× pilot volume** and are intentionally under-tested in the baseline.
- Some requests are interactive; others are batch/background operations.
- AI/model calls can be slower and less reliable than ordinary application calls.
- Support work occasionally needs elevated access, but persistent standing admin is not acceptable as the target state.

## Workshop ambiguity intentionally retained
Not every desired target is specified. Participants must distinguish:
1. observed repository fact,
2. business requirement,
3. engineering inference,
4. unresolved question,
5. proposed target-state decision.

The exercise rewards evidence-backed decisions, not arbitrary modernization.
