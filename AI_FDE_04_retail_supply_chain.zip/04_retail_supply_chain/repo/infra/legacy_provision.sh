#!/usr/bin/env bash
# DELIBERATELY MANUAL/UNSAFE TRAINING SCRIPT
set -x
export DB_PASSWORD="TRAINING-PLAINTEXT-PASSWORD"
export ADMIN_TOKEN="TRAINING-SHARED-ADMIN-TOKEN"
echo "Create one public network and open application port to 0.0.0.0/0"
echo "Create mutable VM named production-latest"
echo "Create database with public access; backups TBD"
echo "Copy config/settings.yaml manually"
echo "Run app as shared svc-app administrator"
