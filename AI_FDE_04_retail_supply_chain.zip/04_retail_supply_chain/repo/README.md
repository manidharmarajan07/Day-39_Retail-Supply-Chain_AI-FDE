# Retail Supply Chain & Demand Replenishment — Brownfield Repository

> **Training warning:** this repository intentionally contains insecure and operationally immature patterns. All secrets and records are synthetic. Do **not** treat this as production reference code.

## Run locally
```bash
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Smoke endpoints
- `GET /health`
- `GET /records`
- `GET /records/{record_id}`
- `POST /admin/reprocess`
- `GET /ai/score?record_id=...`
- `GET /debug/config`

The baseline is expected to run, but **not** to pass a production-readiness review. Discover the problems before correcting them.

## Additional synthetic evidence
This repository includes a deliberately diverse synthetic evidence pack:
- `DATA_CATALOG.md`
- `BUSINESS_CONTEXT.md`
- `data/*.csv` domain datasets
- `environment_matrix.csv`
- `identity/legacy_access_expanded.csv`
- `ops/known_risks.csv`
- `data/incident_history.csv`

Use these as evidence during discovery. They do **not** represent a correct target state. Some rows and assumptions are intentionally risky, ambiguous or inconsistent.
