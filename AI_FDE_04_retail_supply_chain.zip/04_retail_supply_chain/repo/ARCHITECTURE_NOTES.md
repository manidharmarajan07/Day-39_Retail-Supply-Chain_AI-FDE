# Legacy Architecture Notes — deliberately incomplete

- One API handles public reads, privileged operations and calls to the demand-risk scoring service.
- Application, deployment and support share broad administrator privileges.
- No explicit trust-boundary diagram or network segmentation is maintained.
- Configuration is copied between environments by hand; production values have drifted.
- AI endpoint uses HTTP in the sample config and has no explicit availability/error budget.
- Operations rely on stdout and screenshots; no correlation or distributed tracing.
- Backups are assumed but restore has never been exercised.
- Peak demand is expected to reach 20× the pilot volume.
- Business-critical surface: inventory events, replenishment recommendations, planner actions, network administration, demand-risk scoring.
- Known unknown: who owns certificate renewal and privileged emergency access.
