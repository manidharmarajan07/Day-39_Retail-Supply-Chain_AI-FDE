# Synthetic Data Catalog

**Case:** Retail Supply Chain & Demand Replenishment

> All records are synthetic and intentionally contain normal, edge, degraded, and contradictory patterns for workshop analysis.

## Datasets

- `demand_forecasts.csv` — **140 rows**; use for domain analysis, authorization/scoping, reliability, performance, observability and production-readiness reasoning.
- `incident_history.csv` — **6 rows**; use for domain analysis, authorization/scoping, reliability, performance, observability and production-readiness reasoning.
- `inventory_snapshots.csv` — **220 rows**; use for domain analysis, authorization/scoping, reliability, performance, observability and production-readiness reasoning.
- `orders.csv` — **340 rows**; use for domain analysis, authorization/scoping, reliability, performance, observability and production-readiness reasoning.
- `supplier_shipments.csv` — **95 rows**; use for domain analysis, authorization/scoping, reliability, performance, observability and production-readiness reasoning.

## Workshop use
- Do not assume every row is clean or internally consistent.
- Participants should identify outliers, ambiguous ownership, regional/data-scope implications, and workload/failure patterns.
- Do not “repair” source data merely to make tests pass; document data-quality decisions and preserve traceability.
- Synthetic datasets are evidence inputs, not a solved target state.
