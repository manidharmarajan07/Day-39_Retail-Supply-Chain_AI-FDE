import time, urllib.request
# Deliberately naive: serial calls, averages only, no workload phases or percentiles.
lat=[]
for _ in range(10):
    start=time.time()
    try: urllib.request.urlopen("http://127.0.0.1:8000/records", timeout=5).read()
    except Exception: pass
    lat.append(time.time()-start)
print("average_seconds", sum(lat)/len(lat))
