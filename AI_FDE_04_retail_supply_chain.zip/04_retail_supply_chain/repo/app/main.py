import os
import time
import uuid
from fastapi import FastAPI, Header, HTTPException, Query

app = FastAPI(title='Retail Supply Chain & Demand Replenishment')

# DELIBERATELY PROBLEMATIC BROWNFIELD TRAINING CODE.
# All values are synthetic. Discover first; correct only through T1-T8.
ADMIN_TOKEN = "TRAINING-SHARED-ADMIN-TOKEN"
DB_PASSWORD = "TRAINING-PLAINTEXT-PASSWORD"
MODEL_API_KEY = "TRAINING-MODEL-KEY"
DEPLOY_TOKEN = "TRAINING-DEPLOY-TOKEN"

USERS = {
    "alice": {"role": "admin", "scope": "ALL"},
    "bob": {"role": "admin", "scope": "ALL"},
    "svc-app": {"role": "admin", "scope": "ALL"},
    "svc-deploy": {"role": "admin", "scope": "ALL"},
    "support": {"role": "admin", "scope": "ALL"},
}

RECORDS = [
    {"id":"SKU-701","scope":"south","status":"OPEN","risk_score":0.33},
    {"id":"SKU-702","scope":"west","status":"REVIEW","risk_score":0.86},
    {"id":"SKU-703","scope":"south","status":"EXPEDITE","risk_score":0.73},
    {"id":"SKU-704","scope":"north","status":"CLOSED","risk_score":0.14}
]

@app.get("/health")
def health():
    # Bad: exposes configuration state and says healthy without dependency checks.
    return {"status":"ok","debug":True,"db_password_present":bool(DB_PASSWORD)}

@app.get("/records")
def records(x_user: str = Header(default="anonymous"), scope: str = Query(default="ALL")):
    # Bad: trusts user-controlled identity, ignores scope, returns every record.
    print("AUDIT? user=", x_user, "scope=", scope, "records=", RECORDS)
    return RECORDS

@app.get("/records/{record_id}")
def record(record_id: str, x_user: str = Header(default="anonymous")):
    # Bad: object-level authorization absent.
    for item in RECORDS:
        if item["id"] == record_id:
            return item
    raise HTTPException(status_code=404, detail="not found")

@app.post("/admin/reprocess")
def reprocess(x_admin_token: str = Header(default="")):
    # Bad: shared static administrator secret, blocking work, no idempotency or job boundary.
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="bad token")
    time.sleep(0.35)
    return {"status":"reprocessed","model_key":MODEL_API_KEY,"request_id":str(uuid.uuid4())}

@app.get("/ai/score")
def ai_score(record_id: str):
    # Bad: direct unauthenticated dependency surface, no timeout/retry/breaker/telemetry contract.
    time.sleep(0.05)
    return {"record_id":record_id,"model":'demand-risk scoring service',"score":0.73,"api_key_suffix":MODEL_API_KEY[-4:]}

@app.get("/debug/config")
def debug_config():
    # Bad: synthetic secrets are exposed intentionally for the lab.
    return {"db_password":DB_PASSWORD,"deploy_token":DEPLOY_TOKEN,"model_api_key":MODEL_API_KEY}
