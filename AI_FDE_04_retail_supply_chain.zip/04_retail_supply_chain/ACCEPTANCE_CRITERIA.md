# Acceptance Criteria — Retail Supply Chain & Demand Replenishment

A transformed submission is complete only when evidence exists for all gates below. The untouched brownfield repo is expected to fail many of these.

## 1 Identity & Access
- Human/workload/deployment/support identities inventoried; no normal-path shared standing admin.
- Deny-by-default resource/action authorization with positive and negative tests.
- Scoped RBAC and justified ABAC (region + distribution_center + category); privileged access has expiry/revocation/audit path.
## 2 Secrets & Encryption
- No tracked runtime credential values; no debug secret disclosure; provider/reference pattern implemented.
- Ownership, rotation and certificate lifecycle documented; protected service paths verify TLS.
## 3 IaC Foundation
- Network/runtime/data/security/backup/identity are declarative, modular, parameterized and safely plannable.
## 4 Full-Stack IaC
- App, demand-risk scoring service, policies, observability, scaling and environment contracts are represented; drift strategy exists.
## 5 CI/CD & Supply Chain
- Test/security gates, SBOM, immutable artifact, provenance/signing hooks, controlled promotion and rollback exist; workflow permission is least privilege.
## 6 Observability
- Redacted structured logs, correlation, metrics/traces, AI telemetry, readiness and SLO-linked alert evidence exist.
## 7 Performance & Scalability
- Baseline/ramp/spike/soak tests report p50/p95/p99, throughput, errors and saturation; before/after and 20× capacity assumptions are documented.
## 8 Production Readiness
- Config/vulnerability checks, resilience, restore and rollback are exercised; ownership/runbook/SLO/RTO/RPO/go-live gates are explicit.
## 9 Integration Review
- Cross-control contradictions and dead configuration are resolved or recorded as residual risk; claims point to real artifacts.
## 10 Challenge 1
- New scoped-access requirement is implemented without reintroducing standing broad privilege; permit/deny/audit/expiry evidence exists.
## 11 Challenge 2
- AI degradation under load is bounded, observable and tested; core business flow fails/degrades according to documented policy.
## 12 Final PRD / App Readiness
- `FINAL_APP_PRD.md` is generated only from transformed evidence, distinguishes implemented fact from proposal, and includes testable acceptance + traceability.
