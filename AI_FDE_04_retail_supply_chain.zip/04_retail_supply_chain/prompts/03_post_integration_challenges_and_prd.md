# Post-Integration Challenges

## Challenge 1 — Least-Privilege Change Request
**Scenario:** A third-party logistics planner needs access only to assigned distribution centers and product categories, with automatic expiry of elevated support permissions.

Without weakening the transformed security model, implement this change end-to-end. Update identity/policy, IaC/config and tests; add an expiry/revocation path where relevant; prove both permitted and denied cases; verify audit/trace evidence; and confirm CI/CD plus production-readiness documentation remain consistent. Provide a concise change record: requirement → design → affected artifacts → tests → residual risk.

## Challenge 2 — AI Dependency Resilience Under Load
**Scenario:** Demand scoring latency spikes during a promotion; order and inventory flows must continue with bounded fallback rules and visible model-health state.

Evolve the transformed platform without bypassing established controls. Define the failure policy first, then implement bounded timeout/retry/circuit-breaker/backpressure/fallback behavior as appropriate; expose model-health/degraded-mode telemetry; update load/resilience tests; demonstrate no secret/PII leakage; quantify user/business impact and recovery; and update SLOs/runbook/go-live evidence. Do not fake AI success when the dependency is unavailable.

# Final PRD Prompt — Develop the Final Application
Run this **only after T1–T8, the Final Integration Review, Challenge 1 and Challenge 2 are complete.**

Using the **current transformed repository and its verified evidence as the sole technical source of truth**, create a production-grade PRD for **Supply Replenishment Operations Console**. The PRD must describe the application that should now be built/evolved from this brownfield transformation—not an unrelated greenfield product.

Include:
1. Problem statement, users/personas and measurable business outcomes.
2. In-scope and explicitly out-of-scope capabilities.
3. Functional journeys for normal operations, privileged operations and AI-assisted behavior.
4. Non-functional requirements with measurable SLO/SLA-style targets for availability, latency, throughput, scalability, security, privacy, resilience and recoverability; use repository evidence where available and mark any new target as a proposal.
5. Identity model: human/workload/deployment/support personas, RBAC/ABAC rules, break-glass and audit requirements.
6. Data and AI contracts: inputs/outputs, model dependency, timeout/degraded-mode behavior, human override where appropriate, telemetry and model-version traceability.
7. Target architecture and deployment model grounded in implemented IaC; environment strategy and configuration/secrets contracts.
8. Secure SDLC and release gates: test/security/SBOM/provenance/promotion/rollback requirements.
9. Observability: required logs, metrics, traces, correlation, dashboards, alerts, SLI/SLO mapping and prohibited logging.
10. Performance/capacity model including 20× growth and Challenge 2 behavior.
11. Operational readiness: ownership, runbook, incident handling, backup/restore, RTO/RPO, change and go-live gates.
12. UX/application views required for Retail / Supply Chain operations; keep UI decisions at requirement level unless the transformed repo already proves a choice.
13. API/integration requirements and compatibility constraints with retained brownfield behavior.
14. Acceptance criteria in Given/When/Then form, mapped to automated or inspectable evidence.
15. Traceability matrix: PRD requirement → transformed repo artifact/test/evidence → status.
16. Residual risks, assumptions, open decisions and technical-debt register.
17. A phased final-app implementation backlog: Must / Should / Could, with dependencies and demonstrable definition of done.

**PRD quality gates:** do not invent completed controls; label proposal vs implemented fact; do not include secret values; do not claim production readiness where evidence is missing; every critical requirement must have a verification method. Save as `FINAL_APP_PRD.md`.
