# Discovery Prompts — Retail Supply Chain & Demand Replenishment

> Run D1–D8 **before changing the repository**. Parse code plus `BUSINESS_CONTEXT.md`, `DATA_CATALOG.md`, `data/`, `environment_matrix.csv`, expanded identity records, known risks and incident history. Require file/line evidence. Separate observed fact, inference and unknown. Do not provide fixes unless the prompt explicitly asks for candidate target-state options.

## D1 — System, runtime and trust-boundary discovery
Parse the entire repo. Reconstruct components, entry points, data flows, privileged paths, the demand-risk scoring service, deployment path, configuration sources, operational dependencies and trust boundaries. Identify contradictions between code, config, scripts, CI and docs. Produce: as-is component map, data-flow/trust map, dependency graph, dataset/dependency inventory, stakeholder tension map, top 10 unknowns and an investigation backlog. Correlate at least three findings with synthetic operational evidence.

## D2 — Identity & access discovery
Inventory human/workload/deployment/support identities from code, `identity/`, CI, scripts and config. Map principal → authentication mechanism → role → resource/action → scope → environment. Find shared accounts, wildcard/admin grants, identity spoofing opportunities, missing object-level authorization, missing separation of duties and absent privilege expiry. Propose candidate roles inventory_viewer, replenishment_planner, supply_admin, ml_operator and evaluate whether ABAC dimensions such as **region + distribution_center + category** are justified. Output the as-is access matrix and attack/abuse paths. Cross-check authorization assumptions against domain data scopes and the expanded legacy access dataset.

## D3 — Secrets, credentials & encryption discovery
Search tracked code/config/scripts/CI/docs for tokens, passwords, keys, URLs, certificate assumptions and transport settings. **Redact values in output.** Build a secret inventory: owner, consumer, environment, storage, scope, rotation, expiry and blast radius. Identify plaintext material, insecure transport, missing encryption boundaries, unsafe debug disclosure and absent certificate lifecycle.

## D4 — Infrastructure & configuration discovery
Reverse-engineer the current infrastructure from `infra/`, Dockerfile, settings and docs. Identify exposure, ingress/egress, runtime, data store, AI endpoint, identity bindings, backups, mutable/manual steps and environment drift. Produce an as-is deployment model plus a cloud-agnostic IaC decomposition with state, module and environment boundaries.

## D5 — CI/CD & software-supply-chain discovery
Audit workflow permissions, dependency constraints, tests, lint/type checks, SAST, SCA, secret scan, IaC scan, container scan, SBOM, provenance/signing, artifact identity, promotion, production approvals, deploy identity, post-deploy validation and rollback. Distinguish repo evidence from controls that would require platform settings outside the repo. Output pipeline risk table and minimum secure gates.

## D6 — Observability & distributed-tracing discovery
Follow one representative request from API entry to demand-risk scoring service. Determine whether logs are structured, correlated and safe; whether metrics describe traffic/errors/latency/saturation; whether traces cross the AI dependency; and whether dashboards/alerts map to an SLO. Identify leakage caused by current logging/debug behavior. Define a telemetry contract and missing evidence. Use incident history and domain datasets to identify which dimensions/correlation fields are required for useful diagnosis.

## D7 — Performance, load & scalability discovery
Critique `naive_load_test.py`; define a realistic workload model for baseline, ramp, spike and sustained/soak load at up to 20× pilot. Identify blocking work, queue/backpressure gaps, timeouts, model bottlenecks, resource saturation and cost signals. Define p50/p95/p99, throughput, error-rate and saturation thresholds **before** implementation. Derive at least two representative workload mixes from the expanded synthetic datasets rather than testing only a single endpoint pattern.

## D8 — Security & production-readiness discovery
Perform a cross-cutting readiness review: authn/authz, secrets, exposure/configuration, dependencies, backup/restore, rollback, resilience, AI degradation, incident ownership, runbooks, monitoring, RTO/RPO assumptions and objective go-live gates. Produce a risk-ranked backlog with severity, evidence, business impact, owner-to-be-assigned and verification method.
