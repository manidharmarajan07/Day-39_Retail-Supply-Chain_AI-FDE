# Transformation Prompts — Retail Supply Chain & Demand Replenishment

> Start only after D1–D8. Use the expanded synthetic evidence pack to validate that changes work across multiple scopes, roles, workload shapes, failure modes and edge cases—not just a happy-path sample. Every prompt must preserve traceability: **Finding → Decision → Change → Test → Evidence**. Prefer controlled brownfield evolution over wholesale replacement.

## T1 — Identity & Access Review — Least-Privilege Redesign
Using discovered evidence, implement explicit authentication/authorization boundaries. Separate human, runtime, deployment and support identities; remove shared standing admin from normal paths; implement resource/action-scoped RBAC with roles such as inventory_viewer, replenishment_planner, supply_admin, ml_operator; add ABAC only where justified by region + distribution_center + category; enforce deny-by-default and object-level authorization; define time-bound break-glass; add positive/negative tests using multiple principals, scopes and records drawn from the synthetic evidence pack. Produce `docs/access-model.md`, a machine-readable policy representation, migration notes and tests proving former excessive paths are denied.

## T2 — Secrets, Credentials & Encryption Hardening
Remove synthetic hard-coded credentials from runtime/config/CI and prevent debug disclosure. Introduce a cloud-agnostic secret-provider/config interface, separated by workload and environment. Define secret owner/purpose/scope/rotation/expiry metadata, TLS verification, encryption-at-rest/in-transit requirements and certificate issuance/renewal/revocation responsibility. Add secret-scanning and fail-safe tests for missing/invalid secrets. Do not commit replacement secret values.

## T3 — Infrastructure as Code — Foundation Build
Replace manual provisioning with modular declarative IaC for network segmentation, ingress/egress, compute/runtime, database/storage, backup, security boundaries and workload identity bindings. Parameterize environments, define state/locking guidance, outputs, validation/format/policy checks and non-destructive plan workflow. Keep provider-specific code isolated if a provider is selected.

## T4 — Full-Stack Infrastructure as Code
Extend IaC across application service, demand-risk scoring service, data stores, service identities, policy attachments, environment config, observability dependencies, scaling controls and deployment contracts. Make dev/test/prod reproducible from parameters rather than copied files. Add dependency ordering, secrets references, outputs, drift-detection strategy and change-review expectations.

## T5 — Secure CI/CD & Software Supply Chain
Replace direct-to-production behavior with deterministic build/test/security stages: pinned/controlled dependencies and actions where practical, unit/integration/authz tests, lint/type checks, SAST/SCA, secret scan, IaC scan, artifact/container scan, SBOM, immutable versioned artifact, provenance/signing hooks, least-privilege deploy identity, promotion, approval, post-deploy verification and rollback. Explicitly document controls that require repository/platform settings outside the workflow file.

## T6 — Observability & Distributed Tracing
Implement structured redacted logs, propagated correlation/request ID, OpenTelemetry-compatible traces, service metrics, AI-call latency/error/timeout metrics, health/readiness distinction, dashboards-as-code stubs and actionable SLO-linked alerts. Demonstrate multiple representative traces: normal success, authorization denial, degraded AI dependency and one high-latency or error path using synthetic record identifiers. Ensure secrets and sensitive business records are not logged.

## T7 — Performance, Load & Scalability Validation
Replace the serial-average script with a reproducible workload suite covering baseline, ramp, spike and sustained/soak phases. Capture p50/p95/p99, throughput, error rate, concurrency, resource/saturation signals, AI latency and a cost proxy. Introduce justified controls such as bounded concurrency, timeout budgets, backpressure, queueing/caching or scaling policies; rerun against at least two dataset-derived workload mixes and produce before/after evidence plus capacity triggers.

## T8 — Security Validation & Production Readiness
Run final configuration/vulnerability validation and close or explicitly accept residual findings. Add resilience/failure-injection evidence, backup/restore exercise, rollback test, runbook, ownership/RACI, SLI/SLO definitions, alert routing, RTO/RPO assumptions and objective go-live gates. Produce `PRODUCTION_READINESS.md`; unresolved critical risk must block go-live rather than disappear from the report.

## Final AI FDE Integration Review Prompt
Act as a skeptical principal FDE reviewing the fully transformed repo. Cross-check all eight areas against one another rather than assessing them independently. Verify identities referenced by IaC match runtime/pipeline identities; policies match code paths; secret references exist but values do not; CI deploys the IaC/app artifacts it actually builds; telemetry covers real request paths and demand-risk scoring service; performance tests exercise the target architecture; runbooks/rollback/restore commands correspond to real artifacts; and readiness claims are backed by tests/evidence. Find contradictions, dead config, duplicated controls, insecure compatibility leftovers, orphaned files, weak tests and aspirational claims. Produce a punch-list with severity and evidence. Fix only high-confidence defects, re-run validation, and produce `docs/integration-review.md` with remaining risks.

# Post-Integration Challenges

## Challenge 1 — Least-Privilege Change Request
**Scenario:** A third-party logistics planner needs access only to assigned distribution centers and product categories, with automatic expiry of elevated support permissions.

Without weakening the transformed security model, implement this change end-to-end. Update identity/policy, IaC/config and tests; add an expiry/revocation path where relevant; prove both permitted and denied cases; verify audit/trace evidence; and confirm CI/CD plus production-readiness documentation remain consistent. Provide a concise change record: requirement → design → affected artifacts → tests → residual risk.

## Challenge 2 — AI Dependency Resilience Under Load
**Scenario:** Demand scoring latency spikes during a promotion; order and inventory flows must continue with bounded fallback rules and visible model-health state.

Evolve the transformed platform without bypassing established controls. Define the failure policy first, then implement bounded timeout/retry/circuit-breaker/backpressure/fallback behavior as appropriate; expose model-health/degraded-mode telemetry; update load/resilience tests; demonstrate no secret/PII leakage; quantify user/business impact and recovery; and update SLOs/runbook/go-live evidence. Do not fake AI success when the dependency is unavailable.

# Final PRD Prompt — Develop the Final Application
Run this **only after T1–T8, the Final Integration Review, Challenge 1 and Challenge 2 are complete.**

Using the **current transformed repository and its verified evidence as the sole technical source of truth**, create a production-grade PRD for **Supply Replenishment Operations Console**. The PRD must describe the application that should now be built/evolved from this brownfield transformation—not an unrelated greenfield product.

Include:
1. Problem statement, users/personas and measurable business outcomes.
2. In-scope and explicitly out-of-scope capabilities.
3. Functional journeys for normal operations, privileged operations and AI-assisted behavior.
4. Non-functional requirements with measurable SLO/SLA-style targets for availability, latency, throughput, scalability, security, privacy, resilience and recoverability; use repository evidence where available and mark any new target as a proposal.
5. Identity model: human/workload/deployment/support personas, RBAC/ABAC rules, break-glass and audit requirements.
6. Data and AI contracts: inputs/outputs, model dependency, timeout/degraded-mode behavior, human override where appropriate, telemetry and model-version traceability.
7. Target architecture and deployment model grounded in implemented IaC; environment strategy and configuration/secrets contracts.
8. Secure SDLC and release gates: test/security/SBOM/provenance/promotion/rollback requirements.
9. Observability: required logs, metrics, traces, correlation, dashboards, alerts, SLI/SLO mapping and prohibited logging.
10. Performance/capacity model including 20× growth and Challenge 2 behavior.
11. Operational readiness: ownership, runbook, incident handling, backup/restore, RTO/RPO, change and go-live gates.
12. UX/application views required for Retail / Supply Chain operations; keep UI decisions at requirement level unless the transformed repo already proves a choice.
13. API/integration requirements and compatibility constraints with retained brownfield behavior.
14. Acceptance criteria in Given/When/Then form, mapped to automated or inspectable evidence.
15. Traceability matrix: PRD requirement → transformed repo artifact/test/evidence → status.
16. Residual risks, assumptions, open decisions and technical-debt register.
17. A phased final-app implementation backlog: Must / Should / Could, with dependencies and demonstrable definition of done.

**PRD quality gates:** do not invent completed controls; label proposal vs implemented fact; do not include secret values; do not claim production readiness where evidence is missing; every critical requirement must have a verification method. Save as `FINAL_APP_PRD.md`.
